<?php
include "includes/config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin contact</title>
    <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    body{
        background-image: url('images/banner2.jpg');
    }
    .navbar-toggler {
        z-index: 1;
    }
    .navbar{
        border-radius:0;
        width:100%;
        position:absolute;
        top:0px;
    }
    .collapse{
        float:right;
        padding-top:20px;
    }
    .nav-item{
        padding-left:20px;
    }
    /* .navbar-brand{
        padding:0px 0px 50px 0px;
    } */
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }

    .carousel-item.active,
    .carousel-item-next,
    .carousel-item-prev {
        display: block;
    }
    a{
        margin:10px;
    }
    h1{
        font-weight:bold;
    }
    .card{
        padding:20px;
        position:absolute;
        left:77%;
        top: 100px;
        color: #ff0000;
    }
    </style>

</head>
<body>
    <?php
    include "includes/header.php"
    ?>
    <center>
    <div class="card">
        <h1> Kusuma </h1>
        <span>
            <h3>contact no:</h3> <p>981234567</p>
        </span>
    </div>
    </center>
</body>
</html>