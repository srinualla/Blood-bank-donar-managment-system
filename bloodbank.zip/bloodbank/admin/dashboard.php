<?php
session_start();
include "includes/config.php";
if(!isset($_SESSION['user']))
{	
	header('Location: index.php');
}
?>
<!doctype html>
<html>

<head>
	<title>BBDMS | Admin Dashboard</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
</head>
<body>
<?php include('includes/header.php');?>
<div class="ts-main-content">
<?php include('includes/leftbar.php');?>
		<div class="content-wrapper">
			<div class="container-fluid">
				<div class="row">
					<div class="col-md-12">
						<h2 class="page-title">Dashboard</h2>
						<div class="row">
							<div class="col-md-12">
								<div class="row">
								<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-success text-light">
												<div class="stat-panel text-center">
												<?php 
													$sql2 ="SELECT id from tblbloodgroup";
													$query2 = mysqli_query($con,$sql2);
													$row2=mysqli_num_rows($query2);
													?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($row2);?></div>
													<div class="stat-panel-title text-uppercase">Registered Blood Donors</div>
												</div>
											</div>
											<a href="donor-list.php" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
									<div class="col-md-3">
										<div class="panel panel-default">
											<div class="panel-body bk-primary text-light">
												<div class="stat-panel text-center">
												<?php 
													$sql3 ="SELECT id from tblblooddonars";
													$query3 = mysqli_query($con,$sql3);
													$row3=mysqli_num_rows($query3);
												?>
													<div class="stat-panel-number h1 "><?php echo htmlentities($row3);?></div>
													<div class="stat-panel-title text-uppercase">Registered Blood Group</div>
												</div>
											</div>
											<a href="" class="block-anchor panel-footer text-center">Full Detail &nbsp; <i class="fa fa-arrow-right"></i></a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
