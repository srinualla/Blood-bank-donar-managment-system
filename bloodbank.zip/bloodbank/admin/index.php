<?php
session_start();
include 'includes/config.php';
$con = mysqli_connect("localhost","root","","bbdms");

if(isset($_POST['login'])){
	$name=$_POST['username'];
	$password=$_POST['password'];
	$sql = "SELECT * FROM admin WHERE username = '$name' AND password ='$password'";
	$query = mysqli_query($con,$sql);
	$row = mysqli_fetch_array($query,MYSQLI_ASSOC);
	$active = $row['active'];
	$count = mysqli_num_rows($query);
	if($count == 1) {
	   $_SESSION['user'] = $name;
	   header("Location: dashboard.php");
	}else {
	   echo '<script>alert("Your Login Name or Password is invalid") </script>' ;
	}
}
?>
<!doctype html>
<html lang="en" class="no-js">

<head>
	<title>BloodBank & Donor Management System | Admin Login</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<style>

	.navbar{
		background:#333;
        border-radius:0;
        width:100%;
        position:absolute;
        top:0px;
    }
    .collapse{
        float:right;
        padding-top:20px;
    }
    .nav-item{
        padding-left:20px;
    }

	</style>
</head>

<body>
	<div class="login-page bk-img" style="background-image: url(img/banner.png);">
		<div class="form-content">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-md-offset-3">
						<h1 class="text-center text-bold mt-4x">BloodBank & Donor Management System Sign in</h1>
						<div class="well row pt-2x pb-3x bk-light">
							<div class="col-md-8 col-md-offset-2">
								<form method="post">
									<label for="" class="text-uppercase text-sm">Your Username </label>
									<input type="text" placeholder="Username" name="username" class="form-control mb">
									<label for="" class="text-uppercase text-sm">Password</label>
									<input type="password" placeholder="Password" name="password" class="form-control mb">
									<button class="btn btn-primary btn-block" name="login" type="submit">LOGIN</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
