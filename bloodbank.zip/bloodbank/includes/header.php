<nav class="navbar fixed-top navbar-toggleable-md navbar-inverse bg-inverse">
    <div class="container">
        <a class="navbar-brand" href="index.php">BloodBank & Donor Management System</a>
        <div class="collapse navbar-collapse" id="navbarExample">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="become-donar.php">Become a Donar</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="admin/index.php">Admin Login</a>
                </li>
                <li class="nav-item">   
                    <a class="nav-link" href="contact.php">Contact</a>
                </li>
                
            </ul>
        </div>
    </div>
</nav>
