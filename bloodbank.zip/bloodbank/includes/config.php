<?php 
// DB credentials.
$con = mysqli_connect("localhost","root","","bbdms");
?>