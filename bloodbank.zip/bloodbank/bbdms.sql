-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 26, 2020 at 04:57 PM
-- Server version: 10.3.15-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bbdms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `updationdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationdate`) VALUES
(1, 'admin', '1234', '2020-02-08 16:28:18');

-- --------------------------------------------------------

--
-- Table structure for table `tblblooddonars`
--

CREATE TABLE `tblblooddonars` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `password` varchar(11) NOT NULL,
  `mobile_num` char(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `bloodgroup` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `msg` mediumtext NOT NULL,
  `date` date NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblblooddonars`
--

INSERT INTO `tblblooddonars` (`id`, `name`, `password`, `mobile_num`, `email`, `gender`, `age`, `bloodgroup`, `address`, `msg`, `date`, `status`) VALUES
(1, 'Anuj Kumar', '', '9999857868', 'anuj@gmail.com', 'Male', 27, 'O+', ' bdhdh dhf hd h', ' d hd hd fh d', '2017-07-01', 1),
(2, 'dasdasd', '', '41241241241', 'dasdasd@dfdsf.com', 'Male', 34, 'AB-', ' fsdfds', ' fsdf', '2017-07-01', 1),
(3, 'Ami', '', '42352352352', '', 'Male', 23, 'A+', '', ' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ', '2017-07-01', 1),
(4, 'fdsfsgg', '', '35345435345', '', 'Female', 26, 'AB-', '', ' Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. ', '2017-07-01', 1),
(5, 'Nitesh Kumart', '', '8569855244', 'niiii@test.com', 'Male', 32, 'A-', 'Test Demo', 'Test demo Test demoTest demoTest demoTest demoTest demoTest demoTest demoTest demoTest demoTest demoTest demoTest demo', '2017-07-01', 1),
(6, 'ss', '1234', '1234', 'sdfg', 'gfd', 12, 'ds', 'asxd', 'ds', '2020-02-12', 1),
(7, 'Srinu Alla', '', '09866128257', '', 'Male', 12, 'A-', 'D.no: 22-111-1,dayal nagar,Peda gantyada, Gajuwaka', ' 124', '0000-00-00', 1),
(8, 'Srinu Alla', '123456', '09866128257', 'srinualla542@gmail.com', 'Female', 12, 'A-', 'D.no: 22-111-1,dayal nagar,Peda gantyada, Gajuwaka', ' fd', '0000-00-00', 1),
(9, 'Srinu Alla', '122233', '09866128257', 'srinualla542@gmail.com', 'Male', 12, 'AB-', 'D.no: 22-111-1,dayal nagar,Peda gantyada, Gajuwaka', ' 123456', '0000-00-00', 1),
(10, 'Srinu Alla11222', '', '09866128257', '', 'Male', 1234, 'A-', 'D.no: 22-111-1,dayal nagar,Peda gantyada, Gajuwaka', ' ds', '0000-00-00', 1),
(11, 'hassi', '', '1355667899', '', 'Female', 20, 'A-', '', ' ', '0000-00-00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblbloodgroup`
--

CREATE TABLE `tblbloodgroup` (
  `id` int(11) NOT NULL,
  `BloodGroup` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblbloodgroup`
--

INSERT INTO `tblbloodgroup` (`id`, `BloodGroup`) VALUES
(1, 'A-'),
(2, 'AB-'),
(3, 'O-'),
(4, 'A-'),
(5, 'A+'),
(6, 'AB+'),
(7, 'A++'),
(8, 'A++'),
(9, 'a'),
(10, 'a');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblblooddonars`
--
ALTER TABLE `tblblooddonars`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblbloodgroup`
--
ALTER TABLE `tblbloodgroup`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tblblooddonars`
--
ALTER TABLE `tblblooddonars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tblbloodgroup`
--
ALTER TABLE `tblbloodgroup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
