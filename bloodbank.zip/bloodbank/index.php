<?php
error_reporting(0);
include('includes/config.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>BloodBank & Donor Management System</title>
    <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    .navbar{
        border-radius:0;
        width:100%;
        position:absolute;
        top:0px;
    }
    .collapse{
        float:right;
        padding-top:20px;
    }
    .nav-item{
        padding-left:20px;
    }
    /* .navbar-brand{
        padding:0px 0px 50px 0px;
    } */
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }

    .carousel-item.active,
    .carousel-item-next,
    .carousel-item-prev {
        display: block;
    }
    a{
        margin:10px;
    }
    .card{
        margin-top:10px;
        width:200px;
    }
    </style>
</head>
<body>

<?php include('includes/header.php');?>
<?php include('includes/slider.php');?>
<div class="container">
    <div class="row">
            <?php 
            $status=1;
            $sql = "SELECT * from tblblooddonars where status='$status'";
            $query = mysqli_query($con,$sql);
            while($row=mysqli_fetch_assoc($query)){
            ?>

            <div class="col-lg-2 portfolio-item">
                <div class="card h-100">
                    <a href="#"><img class="card-img-top img-fluid img" src="images/blood-donor.jpg" alt="" ></a>
                    <div class="card-block">
                        <h4 class="card-title"><a href="#"><?php echo htmlentities($row['name']);?></a></h4>
                        <p class="card-text"><b>  Gender :</b> <?php echo htmlentities($row['gender']);?></p>
                        <p class="card-text"><b>Blood Group :</b> <?php echo htmlentities($row['bloodgroup']);?></p>
                        <p class="card-text"><b>Mobile number :</b> <?php echo htmlentities($row['mobile_num']);?></p>
                    </div>
                </div>
            </div>
            <?php } ?>
        </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
